let age = parseInt(prompt("Ingrese su edad..."))
let c = 0

do {
    console.log(c)
    c++
} while (c <= age)
console.log(`Program terminated!`)