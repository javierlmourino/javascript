var media = 7
var nota01 = parseInt(prompt())
var nota02 = parseInt(prompt())
var nota03 = parseInt(prompt())
var promedio = (nota01 + nota02 + nota03) / 3

if (promedio > media){
document.write('Aluno APROVADO ')
}
else{
document.write('Aluno REPROVADO')
}